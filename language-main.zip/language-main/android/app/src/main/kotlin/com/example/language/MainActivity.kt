package com.example.language

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
